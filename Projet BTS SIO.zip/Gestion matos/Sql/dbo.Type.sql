﻿CREATE TABLE [dbo].[Type] (
    [idtype]  INT          NOT NULL,
    [nomtype] VARCHAR (50) NULL, 
    CONSTRAINT [PK_Type] PRIMARY KEY ([idtype])
);

