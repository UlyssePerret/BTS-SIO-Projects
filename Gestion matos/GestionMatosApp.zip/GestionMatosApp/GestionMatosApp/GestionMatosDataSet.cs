﻿namespace GestionMatosApp {
    
    
    public partial class GestionMatosDataSet {
    }
}

namespace GestionMatosApp.GestionMatosDataSetTableAdapters {
    
    
    public partial class ClientTableAdapter {
    }
}
