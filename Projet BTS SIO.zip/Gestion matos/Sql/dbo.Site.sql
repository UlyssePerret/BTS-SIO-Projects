﻿CREATE TABLE [dbo].[Site] (
    [id]  INT          NOT NULL,
    [nom] VARCHAR (50) NULL, 
    CONSTRAINT [PK_Site] PRIMARY KEY ([id])
);

