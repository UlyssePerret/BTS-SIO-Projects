<!DOCTYPE html > 

    <head> 
		<meta charset="utf-8" /> 
        <title>Athena/Contact</title> 
				
<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	
    </head> 
    <body>


        <div class="container">
 <!-- contact-->  
 <div class="contact">
<div class="row">
<div class="col-md-offset-2 col-md-8">
<h1> Ecrivez un message </h1>
</div>
</div>

     <form action="formulairecontact.php" method="post">
<div class="row">
    
<div class="col-md-offset-1 col-md-8">
<div class="form-group">
<label for="Nom">Nom</label>
<input type="text" class="form-control" name="nom" placeholder="nom" require>
</div>
</div>
</div>

 <div class="row">
<div class="col-md-offset-1 col-md-8">
<div class="form-group">
<label for="Email">Email</label>
<input type="text" class="form-control" name="email" placeholder="email" require>
</div>
</div>
</div>

        <div class="row"> 
<div class="col-md-offset-1 col-md-8">
<div class="form-group">
    <label for="Objet">Objet</label>
    <input type="text" class="form-control" name="objet" placeholder="objet" require>

    </div>
</div>
    </div>

    <div class="row"> 
<div class="col-md-offset-1 col-md-8">
<div class="form-group">
    <label for="Message">Message</label>
    <input type="text" class="form-control" name="message" placeholder="message" require>

    </div>
</div>
    </div>

<br/>
<div class="row">
<div class="col-md-offset-5 col-md-1">
<input name="envoi" type="submit" class="btn btn-primary" value="Envoyer"/>
</div>
</div>
 </form>
</div>   
 
<!-- Ajout des comptes php-->
<div id='envoi'>
    <?php
    
    if (isset($_POST['envoi'])) 
        {
        
$destinataire = 'ulysseperret@orange.fr' ;
       
$nomexpediteur = htmlspecialchars($_POST['nom']);
$mailexpediteur = htmlspecialchars($_POST['email']);
       
$objet = htmlspecialchars($_POST['objet']);
$message = htmlspecialchars($_POST['message']);
       
mail($destinataire , $objet , $message );

        
        }
       // sendmail()

?>
    </div>

</div>
    </body>