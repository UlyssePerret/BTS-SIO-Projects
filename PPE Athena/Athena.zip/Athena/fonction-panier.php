<?php
// Creation du panier
function creationPanier()
{
if(!isset($_SESSION['panier']))
{
$_SESSION['panier'] = array();
$_SESSION['panier']['libelleProduit'] = array();
$_SESSION['panier']['qteProduit'] = array();
$_SESSION['panier']['prixProduit'] = array();

}
return true;
}

//Ajouter un article
function ajouterArticle($libelleProduit, $qteProduit, $prixPoduit)
{
        // si le panier existe
        if(creationPanier()==true) 
            {
            //si le produit existe déja on ajoute seulement la quantité
            $positionProduit = arrat_search($libelleProduit, $_SESSION['panier']
                    ['libelleProduit']);
            
            if ($positionProduit !== false)
            {
                $_SESSION['panier']['qteProduit'][$libelleProduit] += $qteProduit;
                
            }
            
            // ajout du prouit
        else 
            {
    array_push( $_SESSION['panier']['libelleProduit'],$libelleProduit);
    array_push( $_SESSION['panier']['qteProduit'],$qteProduit);
    array_push( $_SESSION['panier']['prixProduit'],$prixProduit);
            }
        }

else
    echo "Un probléme est survenu veuillez contacter l'administrateur du site";
}

function modifierQTeARticle($libelleProduit, $qteProduit)
{
    if(creationPanier())
    {
        if($qteProduit >0)
        {
            
            $positionProduit = array_search($libelleProduit, $_SESSION['panier']['libelleProduit']) ;
            
            if ($prositionProduit !== false)
            {
                $_SESSION['panier']['qteProduit'][$positionProduit] = $qteProduit;
            }
        }
        else
        supprimeArticle ($libelleProduit);
     }
else
{
    echo " un probleme survenu vueillez contacter l'admin";
    
    }
}

//Montant du panier
function MontantGlobal()
{
  $total = 0;
for ($i = 0; $i < count($_SESSION['panier']['libelleProduit']); $i++)  
{
    $total += $_SESSION['panier']['qteProduit'][$i] * $_SESSION['panier']['prixProduit'][$i];
}
return $total;    
}

//compter les artciles
function compterArticles()
{
  if(isset($_SESSION['panier']))
      return count($_SESSION['panier']['libelleProduit']);
  else
      return 0;
}

// suppresion  d'un article
function supprimeArticle($libelleProduit)
{
    if (creationPanier())
    {
        
        //panier tampon
        $tmp = array();
  $tmp['libelleProduit'] = array();
$tmp['qteProduit'] = array();
$tmp['prixProduit'] = array();

for ($i = 0; $i < count($_SESSION['panier']['libelleProduit']); $i++) 
{
    if($_SESSION['panier']['libelleProduit'][$i] == $libelleProduit)
    {
    array_push($tmp['libelleProduit'] ,$_SESSION['panier']['libelleProduit'][$i]);
    array_push($tmp['qteProduit'] ,$_SESSION['panier']['qteProduit'][$i]);
    array_push($tmp['prixProduit'],$_SESSION['panier']['prixProduit'][$i]);
    }
}
//remplace le panier en session par notre panier temporaire
$_SESSION['panier']= $tmp;

// suppression temportaire
unset($tmp);
    
}
}

//suppresion d'un panier
function supprimerPanier()
{
    unset($_SESSION['panier']);
}

        ?>
