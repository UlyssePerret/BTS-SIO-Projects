<?php session_start();if(!isset($_SESSION["nom"])){	header("location:formulairesimple.php");}?>
<html><head><meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style.css" />
</head><body><div class="haut"><p>
<img src="image/logo_ipssi.png" alt="logo Ipssi" />
<img src="image/logo2.png" alt="logo Ip-Formation" /></p><p>
<a href="cahierdetexte.php">Accueil</a> | 
<a href="recherche.php">Recherche</a> | 
<a href="mentionlegalc.php">Mention legal</a> | 
<a href="faq.php" > FAQ </a> | 
<a href="deconnexion.php">Deconnexion</a>
</p></div><p>Vous êtes <?php 
@mysql_connect("localhost", "root", "");
mysql_select_db("ppe2");
$noms =$_SESSION["nom"];
$req2 = "SELECT IdGroupe FROM utilisateur WHERE nom='$_SESSION[nom]' ";
$res2 = mysql_query($req2);
$ligne2 = @mysql_fetch_assoc($res2);
echo $_SESSION["nom"]." " ;
echo $_SESSION["prenom"] ;
$var=$ligne2["IdGroupe"];
$req3= "SELECT `NiveauSecurite` FROM `groupe` WHERE `IdGroupe`='$var' ";
$res3 = mysql_query($req3);
$ligne3 = @mysql_fetch_assoc($res3);
echo " et vous avez le statut de ".$ligne3["NiveauSecurite"];
$var2=$ligne3["NiveauSecurite"];
if ($ligne3["NiveauSecurite"] != 'Admin')
{	header("location:cahierdetexte.php");}?></p>
<?php //Creation de compte de connexio
@mysql_connect("localhost", "root", "");mysql_select_db("ppe2");
if(isset($_POST["boutonc"]))
{$nom = $_POST["nom"];$prenom = $_POST["prenom"];
$login = $_POST["login"];$mdp = $_POST["mdp"];
$groupe = $_POST["groupe"];$Id = $_POST["Id"];
	if(empty(!$_POST['nom']) AND empty(!$_POST['prenom']) AND empty(!$_POST['login']) AND empty(!$_POST['mdp']) AND empty(!$_POST['groupe']) AND empty(!$_POST['nom']) ) // gestion case vide
{$req4 = "SELECT MAX(`Idutilisateur`) FROM utilisateur "; // pour gerer l'id maximum,
 $res4 = mysql_query($req4);$lign4 = @mysql_fetch_assoc($res4);
$maxid= $lign4["MAX(`Idutilisateur`)"]+1 ; // incrementation de l'id
$req5 = "INSERT INTO `ppe2`.`utilisateur`(`nom`, `prenom`, `mail`, `mdp`, `Idutilisateur`, `IdGroupe`, `Identifiant`) VALUES('$nom', '$prenom', '$login', '$mdp', '$maxid', '$groupe', '$Id')" ; // requete d'insertion
$res5 = mysql_query($req5);$ligne5 = @mysql_fetch_assoc($res5);}
else{echo 'Veuillez remplir toutes les cases<br/><br/>' ;}}?>
<div>Creation de compte de connexion :
<form method="post" action="administratreur.php">
Nom  : <input type="text" name="nom" maxlength="49" placeholder="nom" /><br /><br />
Prenom : <input type="text" name="prenom" maxlength="49" placeholder="prenom" /><br /><br />
Mail : <input type="text" name="login" maxlength="49" placeholder="mail" /><br /><br />
MDP : <input type="text" name="mdp" maxlength="49" placeholder="motdepasse" /><br /><br />
IdGroupe : <input type="text" name="groupe" maxlength="2" placeholder="idgroupe" /><br /><br />
Identifiant : <input type="text" name="Id" maxlength="50" placeholder="identifiant" /><br /><br />
<input type="submit" value="Ajouter" name="boutonc" /></form></br></div>
<div class="Mise_a_jour">Mise a jour du mdp: 
<form method="post" action="administratreur.php">
Id de l'utilisateur : <input type="text" name="idu" maxlength="50" placeholder="identifiant" /><br /><br />
Nouveau mot de passe  : <input type="text" name="mdp1" maxlength="49" placeholder="mot de passe" /><br /><br />
Confirmer mot de passe : <input type="text" name="mdp2" maxlength="49" placeholder="mot de passe" /><br /><br />
<input type="submit" value="Modifier" name="boutonm" /></form>
<?php // Mise à jour du mot de passe
if(isset($_POST["boutonm"]) )
{	$idu = $_POST["idu"];	$mdp1 = $_POST["mdp1"];	$mdp2 = $_POST["mdp2"];
	if($mdp1 == $mdp2 AND empty(!$_POST['mdp1']) AND empty(!$_POST['mdp2']) AND empty(!$_POST['idu'])  )
	{		$req6= 	" UPDATE `ppe2`.`utilisateur` SET `mdp` = '$mdp2' WHERE `utilisateur`.`Idutilisateur` = $idu ";	
$res6 = mysql_query($req6);$ligne6 = @mysql_fetch_assoc($res6);}
else if(empty(!$_POST['mdp1']) AND empty(!$_POST['mdp2']) AND empty(!$_POST['idu']))
	{echo "Erreur, veuillez remplir tout les cases ";}}?>	</div>
<div class="bas">
<a href="mentionlegalc.php">Mention legal</a> |
<a href="plandusite.php" >Plan du Site</a> </br>
© 1998-2013 groupe ip-formation | PARIS : 01 55 43 26 65 | LYON : 0811 692 888 | Tous droits réservés
</div></body></html>