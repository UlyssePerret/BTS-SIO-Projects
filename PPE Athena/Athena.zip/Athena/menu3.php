<!DOCTYPE html > 
<html   lang="fr">
<head> 
	<meta charset="utf-8" /> 
	<title>Athena/Menu2</title> 
	
	<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head> 


<nav id="menu3">
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
        <a class="navbar-brand" href="Acceuil3.php">Athena</a>
    </div>
    <ul class="nav navbar-nav">

      <li class="active"><a href="Acceuil3.php">Accueil</a></li>
   <!-- Consulter, Ajouter et Modifier un compte -->
   
	   <li><a href="gcompte.php">Gestion des comptes</a></li>
           
            <!-- Consulter, Ajouter et Modifier les fiches produit à valider -->
            
            <li><a href="fiche.php">Fiches</a></li>
            
          <!-- Consulter tous les article -->
              <li><a href="carticle.php">Articles</a></li>
              
                <!-- consulter les catégories-->
            <li><a href="mcategorie.php">  Catégories</a></li>
              
    </ul>
    <ul class="nav navbar-nav navbar-right">
		
      <li><a href="deconnexion.php"><span class="glyphicon glyphicon-log-in"></span> Déconnexion</a></li>
    </ul>
  </div>
</nav>
</nav>