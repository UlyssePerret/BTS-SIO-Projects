<html> 
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body><center>
<h1> Formulaire d'enregistrement </h1>
<hr/>
<form method="post" action="ajoutprofil.php" >

<div class="formulaire"> <br />
Nom :</label> <input type="text" name="nom" maxlength="49" placeholder="Nom" /><br /><br />
Prenom :</label> <input type="text" name="prenom" maxlength="49" placeholder="Prenom" /><br /><br />
Identifiant :</label> <input type="text" name="mail" maxlength="49" placeholder="p.nom@ip-formation.net" /><br /><br />
Motdepasse: </label> <input type="password" maxlength="49"  name="mdp" placeholder="Mot de passe" /><br /><br />
<input type="reset" value="Annuler" />
<input type="submit" value="Enregistrer"  />

</form>
</div>
</br>
<div class="bas"">
Mention legal : 
<a href="mentionlegal.php" >ici</a>
</br>

© 1998-2013 groupe ip-formation | PARIS : 01 55 43 26 65 | LYON : 0811 692 888 | Tous droits réservés | Contactez-nous | Informations légales
</div>
</body></html>