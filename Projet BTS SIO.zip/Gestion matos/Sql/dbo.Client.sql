﻿CREATE TABLE [dbo].[Client] (
    [idclient] INT          NOT NULL,
    [Nom]      VARCHAR (50) NULL, 
    CONSTRAINT [PK_Client] PRIMARY KEY ([idclient])
);

