
<!DOCTYPE html > 
<html   lang="fr">
<head> 
	<meta charset="utf-8" /> 
	<title>Athena/Plan du site</title> 
	
	<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head> 
    
<body> 


    
    <!-- Barre de navigation -->
 <?php include("menu1.php"); ?>
    
    <!-- Contenue -->
    
      <h1>Plan du Site</h1>
    

<ul >
    <li><a href="Acceuil.php" >Athena</a></li>
    <ul> 
    <li><a href="Acceuil.php" >Acceuil</a></li>
    <ul><li><a href="affichep.php">Afficher les produits</a></li></ul>
    <li><a href="inscription.php " >Inscription</a></li>
    <li><a href="connexion.php" >Connexion</li>
    <li><a href="connection.php" >traitement de la Connexion</li>
    </ul>


<li><a href="Acceuil2.php">Athena</a></li>
           <ul>
               <li><a href="Acceuil2.php">Acceuil</a></li>
               <ul>
                   <li><a href="affichep.php">Afficher les produits</a></li>
               </ul>
               <li><a href="vendre.php">Ajouter un produit</a> </li>
               <ul>
                   <li><a href="affichepu.php">Afficher les produits que vous vendez</a></li>
                   <li><a href="vendrep.php">Vendre un produit</a></li>
               </ul>
  
               <li><a href="compte.php"> Compte</a> </li>
               <ul>
                   <li><a href="afficheut.php">Afficher votre compte</a></li>
                   <li><a href="modifuco.php">Modifier votre compte</a></li>
               </ul>
               
               <li><a href="rechercher.php.php"> Rechercher</a> </li>
               
           </ul>
<?php
 include ('afficheut.php');
?>

<!--Modification -->
<?php
 include ('modifuco.php');
?>
        
<li><a href="Acceuil3.php">Tableau de bord</a></li>
            <ul >

	   <li><a href="gcompte.php">Gestion des comptes</a></li>
           <ul>
               <li><a href="afficheu.php">Afficher les comptes</a> </li>
               <li><a href="modifu.php"> Modifier les comptes</a> </li>
               <li><a href="ajoutu.php"> Ajouter les comptes</a> </li>
           </ul>
        
            <li><a href="fiche.php">Fiches</a></li>
               <ul>
               <li><a href="affichef.php"> Afficher les fiches</a> </li>
               <li><a href="validerf.php"> Valider les fiches</a> </li>
           </ul>
              <li><a href="carticle.php">Articles</a></li>
              <ul> 
              <li><a href="affichef.php"> Afficher les articles</a> </li>
              </ul>
                <li><a href="mcategorie.php">Catégories</a></li>
              <ul>
               <li><a href="affichec.php"> Afficher les catégories</a> </li>
               <li><a href="ajoutc.php"> Ajouter les catégories</a> </li>
    </ul>

</ul>
</body>
</html>