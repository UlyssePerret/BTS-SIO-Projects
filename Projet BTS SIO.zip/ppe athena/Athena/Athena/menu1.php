<!DOCTYPE html > 
<html   lang="fr">
<head> 
	<meta charset="utf-8" /> 
	<title>Athena/Menu1</title> 
	
	<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head> 

<nav id="menu1">        
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
       <a class="navbar-brand" href="Acceuil.php">Athena</a>
    </div>
	
    <ul class="nav navbar-nav">
   <ul class="nav navbar-nav">
      <li class="active"><a href="Acceuil.php">Accueil</a></li>
    </ul>
    </ul>
	
    <ul class="nav navbar-nav navbar-right">
<li><a href="inscription.php"><span class="glyphicon glyphicon-user"></span> Inscription</a></li>
      <li><a href="connexion.php"><span class="glyphicon glyphicon-log-in"></span> Se connecter</a></li>
    </ul>
  </div>
</nav>
</nav>

