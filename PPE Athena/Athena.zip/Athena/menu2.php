<!DOCTYPE html > 
<html   lang="fr">
<head> 
	<meta charset="utf-8" /> 
	<title>Athena/Menu2</title> 
	
	<link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head> 


<nav id="menu2">
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="Acceuil2.php">Athena</a>
    </div>
    <ul class="nav navbar-nav">
<li class="active"><a href="Acceuil2.php">Accueil</a></li>
<li><a href="vendre.php">Ajouter un produit</a></li>
<li><a href="compte.php">Compte</a></li>
<li><a href="rechercher.php">Rechercher</a></li>
<li><a href="contact.php">Contact</a></li>

    </ul>
	
    <ul class="nav navbar-nav navbar-right">
		<li><a href="panier.php"><span class="glyphicon glyphicon-user"></span>Panier</a></li>
      <li><a href="deconnexion.php"><span class="glyphicon glyphicon-log-in"></span>Deconnexion</a></li>
    </ul>
  </div>
</nav>
</nav>

