<?php session_start(); 
session_destroy();
?>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<div class="haut">
<p>
<img src="image/logo_ipssi.png" alt="logo Ipssi" />
<img src="image/logo2.png" alt="logo Ip-Formation" />
</p>
</div>


<div class="mentionlegal">
<p>
Charif Hachem  : </br>

« Les informations recueillies font l’objet d’un traitement informatique destiné à securiser votre compte sur ce site. Les destinataires des données sont : les administrateurs réseaux et la direction d'Ip-Formation .</br>
</br>
Conformément à la loi « informatique et libertés » du 6 janvier 1978 modifiée en 2004, vous bénéficiez d’un droit d’accès et de rectification aux informations qui vous concernent, que vous pouvez exercer en vous adressant au Service Adminsitration réseau au :</br>
Siège Social</br>
25 rue Claude Tillier</br>
75012 Paris</br>
</br>
Tél : +33 (0)1 55 43 26 65</br>
Fax : +33 (0)1 55 43 26 64</br>

RCS Paris B</br>
SIREN : 420 793 705</br>
n° de déclaration d'existence : 117 533 621 75</br>
Capital social : 60 000 €</br>
Représentant légal : Charif Hachem .</br>
</div class="mentionlegal">

Vous pouvez également, pour des motifs légitimes, vous opposer au traitement des données vous concernant.
</p>
<div class="bas"">
Retournez à l'acceuil : 
<a href="formulairesimple.php" >ici</a>
</br>

© 1998-2013 groupe ip-formation | PARIS : 01 55 43 26 65 | LYON : 0811 692 888 | Tous droits réservés | Contactez-nous | <a href="mentionlegal.php"/>Informations légales</a>
</div>

</body>
</html>